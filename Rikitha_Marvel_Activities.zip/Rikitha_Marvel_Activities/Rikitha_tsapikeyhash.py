# This file contains the timestamp, apikey (public key) and hash (md5 conversion of timestamp, public key and privatekey) and is used in other files


ts='1660764960'
apikey='13f016f6aed8678cdb21338a955b4339'
hash='529ccbd67e981e9cf78ea557b16b7715'